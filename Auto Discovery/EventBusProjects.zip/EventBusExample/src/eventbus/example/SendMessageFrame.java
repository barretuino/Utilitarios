package eventbus.example;

import java.awt.FlowLayout;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.JTextField;

import eventbus.EventBus;

public class SendMessageFrame extends JFrame {

    private final JTextField message;

    private final JButton send;

    public SendMessageFrame() {
        setTitle("Send Message Example");
        setLayout(new FlowLayout());
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        add(new JLabel("Message: "));
        add(message = new JTextField());
        add(send = new JButton("Send"));

        message.setColumns(30);

        send.addActionListener(new ActionListener() {

            public void actionPerformed(final ActionEvent e) {
                EventBus.dispatch(new MessageEvent(
                        this,
                        "message",
                        "Hello World!"));

                message.selectAll();
            }

        });
    }

}
