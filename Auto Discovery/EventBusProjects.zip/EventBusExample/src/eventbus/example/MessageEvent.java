package eventbus.example;

import eventbus.BusEventObject;

public class MessageEvent extends BusEventObject {

    private final String message;

    public MessageEvent(
            final Object source,
            final String name,
            final String message) {

        super(source, name);
        this.message = message;
    }

    public String getMessage() {
        return message;
    }

}
