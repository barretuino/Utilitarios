package eventbus.example;

import javax.swing.JOptionPane;

import eventbus.EventListener;

public class MessageListener {

    private MessageListener() {
    }

    @EventListener
    public static void onMessage(final MessageEvent event) {
        JOptionPane.showMessageDialog(
                null,
                event.getMessage(),
                "Message Event",
                JOptionPane.INFORMATION_MESSAGE);
    }

}
