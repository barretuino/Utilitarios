package eventbus.example;

import javax.swing.SwingUtilities;

public class Main {

    public static void main(final String[] args) {
        SwingUtilities.invokeLater(new Runnable() {

            public void run() {
                final SendMessageFrame sender = new SendMessageFrame();
                sender.setLocationByPlatform(true);
                sender.pack();
                sender.setVisible(true);
            }

        });
    }

}
