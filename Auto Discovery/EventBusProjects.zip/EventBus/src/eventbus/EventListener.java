package eventbus;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * <p>
 * By annotating a method with {@code @EventListener} the method
 * will automatically be invoked when a matched event is fired through
 * the {@link EventBus}.
 * </p><p>
 * The declaration of the event method must match the following
 * signature exactly:
 * </p><p>
 * <code>
 * @EventListener<br>
 * public static void [method-name]([event-type])
 * </code>
 * </p><p>
 * Where [method-name] may be any valid Java identifier (as normal), and
 * [event-type] must be a class that extends {@link BusEventObject}.
 * </p>
 *
 * @author Jason Morris
 */
@Target(ElementType.METHOD)
@Retention(RetentionPolicy.SOURCE)
public @interface EventListener {

    /**
     * <p>
     * The name attribute of an {@code EventListener} annotation can
     * be used to filter the {@link BusEventObject#getName() name}
     * of the event object. The value here may be any valid regex,
     * according to {@link java.util.regex.Pattern Pattern}.
     * By default this will match on any name.
     * </p><p>
     * If the name of the event object does not
     * {@link java.util.regex.Matcher#matches() match} the name of the
     * {@link BusEventObject}, the annotated method will not be invoked.
     * </p>
     *
     * @return by default {@literal ".*"}
     */
    String name() default ".*";

    /**
     * Allows an {@code EventListener} to filter on the source of a
     * triggered event. If the source of the event is an object assignable
     * to the type given here, the event will be triggered. Otherwise
     * the event listener method will not be invoked. By default this
     * value will match any source type.
     *
     * @return by default {@literal Object.class}
     */
    Class<?> source() default Object.class;

}
