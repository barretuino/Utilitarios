package eventbus;

import java.util.List;
import java.util.ArrayList;
import java.util.ServiceLoader;

/**
 * <p>
 * This is our very simple {@code EventBus} class. The class looks for
 * registered {@link EventDispatcher}s when it is first accessed,
 * and then dispatches {@code BusEventObject}s to them.
 * </p><p>
 * Instead of registering your {@code EventDispatcher} with the
 * {@code EventBus} directly, the idea is that you annotate methods
 * with {@link EventListener @EventListener} to receive events from
 * the {@code EventBus} when they are fired.
 * </p>
 *
 * @author Jason Morris
 */
public final class EventBus {

    /**
     * This is our array of {@code EventDispatcher} objects, we instantiate
     * it using a {@link ServiceLoader}.
     */
    private static final EventDispatcher[] DISPATCHERS;

    static {
        final ServiceLoader<EventDispatcher> loader =
                ServiceLoader.load(EventDispatcher.class);

        final List<EventDispatcher> list = new ArrayList<EventDispatcher>();

        for(final EventDispatcher dispatcher : loader) {
            list.add(dispatcher);
        }

        DISPATCHERS = list.toArray(new EventDispatcher[list.size()]);
    }

    /**
     * No public construction.
     */
    private EventBus() {
    }

    /**
     * Dispatch a specified {@code BusEventObject} to any interested
     * {@code EventDispatcher} objects. As an extended example, this
     * method makes no attempt to filter the {@code BusEventObject},
     * and instead relies on the {@code EventDispatcher} to make
     * choose whether or not to fire the event.
     *
     * @param object the {@code BusEventObject} to fire
     */
    public static void dispatch(final BusEventObject object) {
        if(object == null) {
            throw new IllegalArgumentException("null event object");
        }

        for(final EventDispatcher dispatcher : DISPATCHERS) {
            dispatcher.dispatch(object);
        }
    }

    /**
     * Implementations of {@code EventDispatcher} are responsible for
     * filtering and possibly acting on the given events. They are
     * registered using the standard {@link ServiceLoader} mechanism.
     */
    public static interface EventDispatcher {

        /**
         * Filter and possibly act on the given {@code BusEventObject}.
         *
         * @param object the event being fired
         */
        void dispatch(BusEventObject object);

    }
}
