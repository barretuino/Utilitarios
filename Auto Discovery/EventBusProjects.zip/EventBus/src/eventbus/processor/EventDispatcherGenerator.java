package eventbus.processor;

import java.io.Writer;
import java.io.IOException;
import java.io.PrintWriter;

import java.util.List;

import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;

import javax.lang.model.element.Element;
import javax.lang.model.element.ElementKind;
import javax.lang.model.element.TypeElement;
import javax.lang.model.element.PackageElement;
import javax.lang.model.element.VariableElement;
import javax.lang.model.element.ExecutableElement;

import javax.annotation.processing.ProcessingEnvironment;

import javax.lang.model.type.TypeMirror;

import javax.lang.model.util.Types;
import javax.lang.model.util.Elements;

import javax.tools.JavaFileObject;
import javax.tools.Diagnostic.Kind;

import eventbus.EventListener;

/**
 * @author Jason Morris
 */
public class EventDispatcherGenerator {

    private final ProcessingEnvironment environment;

    public EventDispatcherGenerator(final ProcessingEnvironment environment) {
        this.environment = environment;
    }

    private void error(final Element element, final String message) {
        if(element != null) {
            environment.getMessager().printMessage(Kind.ERROR, message, element);
        } else {
            environment.getMessager().printMessage(Kind.ERROR, message);
        }
    }

    private String getDispatcherClassName0(
            final String typeName,
            final ExecutableElement method) {

        final String methodName = method.getSimpleName().toString();
        final String capatalizedMethodName =
                Character.toUpperCase(methodName.charAt(0)) +
                methodName.substring(1);

        return typeName + capatalizedMethodName + "Dispatcher";
    }

    private String getDispatcherClassName(final ExecutableElement method) {
        final TypeElement type = (TypeElement)method.getEnclosingElement();

        return getDispatcherClassName0(
                type.getQualifiedName().toString(),
                method);
    }

    private String getDispatcherSimpleName(final ExecutableElement method) {
        final TypeElement type = (TypeElement)method.getEnclosingElement();

        return getDispatcherClassName0(
                type.getSimpleName().toString(),
                method);
    }

    private String getPackageName(final Element element) {
        Element e = element;

        while(e != null) {
            if(e.getKind() == ElementKind.PACKAGE) {
                return ((PackageElement)e).getQualifiedName().toString();
            }

            e = e.getEnclosingElement();
        }

        return null;
    }

    private TypeElement getEventType(final ExecutableElement method) {
        final List<? extends VariableElement> params = method.getParameters();

        if(params.size() != 1) {
            error(method, "EventListener methods must only take " +
                    "exactly one BusEventObject type.");
        } else {
            final VariableElement element = params.get(0);
            final TypeMirror typeMirror = element.asType();

            final Types types = environment.getTypeUtils();
            final Elements elements = environment.getElementUtils();

            final TypeElement type = (TypeElement)types.asElement(typeMirror);

            final TypeElement busEventObject = elements.getTypeElement(
                    EventListenerAnnotationProcessor.EVENT_TYPE);

            if(types.isAssignable(typeMirror, busEventObject.asType())) {
                return type;
            } else {
                error(method, type.getQualifiedName() +
                        " is not a BusEventObject");
            }
        }

        return null;
    }

    private void printEscapedString(
            final String nameFilter,
            final PrintWriter pw) {

        final int length = nameFilter.length();

        pw.print('\"');

        for(int i = 0; i < length; i++) {
            final char ch = nameFilter.charAt(i);

            switch(ch) {
                case '\\':
                    pw.print("\\\\");
                    break;
                case '\"':
                    pw.print("\\\"");
                    break;
                case '\'':
                    pw.print("\\\'");
                    break;
                case '\n':
                    pw.print("\\n");
                    break;
                case '\r':
                    pw.print("\\r");
                    break;
                case '\f':
                    pw.print("\\f");
                    break;
                case '\b':
                    pw.print("\\b");
                    break;
                default:
                    pw.print(ch);
                    break;
            }
        }

        pw.print('\"');
    }

    public GeneratorResult generate(
            final ExecutableElement method)
            throws IOException {

        final String className = getDispatcherClassName(method);
        final String simpleName = getDispatcherSimpleName(method);
        final TypeElement eventType = getEventType(method);
        final EventListener annotation = method.getAnnotation(EventListener.class);

        final String nameFilter = annotation.name();
        TypeElement sourceFilter = null;

        try {
            final Class<?> type = annotation.annotationType();
            sourceFilter = environment.getElementUtils().getTypeElement(
                    type.getCanonicalName());
        } catch(final TypeNotPresentException tnpe) {
            sourceFilter = environment.getElementUtils().getTypeElement(
                    tnpe.typeName());
        }

        if(className == null || simpleName == null || eventType == null) {
            return null;
        }

        try {
            Pattern.compile(nameFilter);
        } catch(final PatternSyntaxException pse) {
            error(method,
                    "Invalid regex for name filter: '" +
                    nameFilter + "'");

            return null;
        }

        final JavaFileObject file = environment.getFiler().createSourceFile(
                className,
                method);

        assert file != null : "ProcessingEnvironment.filer gave us a null JavaFileObject";

        final Writer writer = file.openWriter();
        final PrintWriter pw = new PrintWriter(writer);

        final String packageName = getPackageName(method);

        if(packageName != null) {
            pw.append("package ").append(packageName).println(';');
            pw.println();
        }

        pw.append("public final class ").append(simpleName).
                println(" implements eventbus.EventBus.EventDispatcher {");

        pw.println();

        if(!nameFilter.equals(".*")) {
            pw.print("\tprivate final java.util.regex.Pattern nameFilter = " +
                    "java.util.regex.Pattern.compile(");

            printEscapedString(nameFilter, pw);

            pw.println(");");
            pw.println();
        }

        pw.println("\tpublic void dispatch(eventbus.BusEventObject event) {");

        pw.print("\t\tif(event instanceof ");
        pw.print(eventType.getQualifiedName());

        if(!nameFilter.equals(".*")) {
            pw.println();
            pw.print("\t\t\t\t&& nameFilter.matcher(event.getName()).matches()");
        }

        if(!sourceFilter.getQualifiedName().contentEquals("java.lang.Object")) {
            pw.println();
            pw.append("\t\t\t\t&& event.getSource() instanceof ").
                    print(sourceFilter.getQualifiedName());
        }

        pw.println(") {");
        pw.println();

        final TypeElement type = (TypeElement)method.getEnclosingElement();
        pw.append("\t\t\t").append(type.getQualifiedName()).append('.').
                append(method.getSimpleName()).append("((").
                append(eventType.getQualifiedName()).println(")event);");

        pw.println("\t\t}");

        pw.println("\t}");

        pw.println("}");

        pw.flush();
        pw.close();

        return new GeneratorResult(file, className);
    }

    public static class GeneratorResult {

        private final JavaFileObject file;

        private final String className;

        private GeneratorResult(
                final JavaFileObject file,
                final String className) {

            this.file = file;
            this.className = className;
        }

        public JavaFileObject getFile() {
            return file;
        }

        public String getClassName() {
            return className;
        }

    }
}
