package eventbus.processor;

import java.io.IOException;

import java.util.Set;
import java.util.List;
import java.util.ArrayList;
import java.util.Collection;

import javax.tools.Diagnostic.Kind;
import javax.tools.StandardLocation;

import javax.annotation.processing.RoundEnvironment;
import javax.annotation.processing.AbstractProcessor;
import javax.annotation.processing.SupportedSourceVersion;
import javax.annotation.processing.SupportedAnnotationTypes;

import javax.lang.model.SourceVersion;

import javax.lang.model.element.Element;
import javax.lang.model.element.Modifier;
import javax.lang.model.element.ElementKind;
import javax.lang.model.element.TypeElement;
import javax.lang.model.element.ExecutableElement;

import javax.lang.model.util.Elements;

import eventbus.processor.EventDispatcherGenerator.GeneratorResult;

/**
 * @author Jason Morris
 */
@SupportedSourceVersion(SourceVersion.RELEASE_5)
@SupportedAnnotationTypes(EventListenerAnnotationProcessor.ANNOTATION_TYPE)
public class EventListenerAnnotationProcessor extends AbstractProcessor {

    public static final String ANNOTATION_TYPE = "eventbus.EventListener";

    public static final String EVENT_TYPE = "eventbus.BusEventObject";

    private void registerMethods(
            final Collection<GeneratorResult> classes)
            throws IOException {

        final ServiceRegistration registration = new ServiceRegistration(
                processingEnv,
                "eventbus.EventBus$EventDispatcher");

        registration.read(StandardLocation.SOURCE_PATH);
        registration.read(StandardLocation.CLASS_PATH);

        for(final GeneratorResult clazz : classes) {
            registration.addClass(clazz.getClassName());
        }

        registration.write(StandardLocation.CLASS_OUTPUT);
    }

    @Override
    public boolean process(
            final Set<? extends TypeElement> annotations,
            final RoundEnvironment roundEnv) {

        if(annotations == null || annotations.isEmpty()) {
            return false;
        }

        final Elements elements = processingEnv.getElementUtils();

        // we need the actual TypeElement of the annotation, not just it's name
        final TypeElement annotation = elements.getTypeElement(ANNOTATION_TYPE);

        // make sure we have the annotation type
        if(annotation != null) {
            // now we can ask for all of the methods being compiled, that
            // are annotated by @EventListener
            final Set<? extends Element> methods =
                    roundEnv.getElementsAnnotatedWith(annotation);

            final EventDispatcherGenerator generator =
                    new EventDispatcherGenerator(processingEnv);

            try {
                // we will need the results of the generation in order
                // to write the services registration file
                final List<GeneratorResult> results =
                        new ArrayList<GeneratorResult>(methods.size());

                for(final Element m : methods) {
                    final Set<Modifier> mods = m.getModifiers();

                    // ensure that the element can be processed
                    if(m.getKind() == ElementKind.METHOD &&
                            mods.contains(Modifier.PUBLIC) &&
                            mods.contains(Modifier.STATIC)) {
                        
                        final ExecutableElement method = (ExecutableElement)m;
                        results.add(generator.generate(method));
                    } else {
                        processingEnv.getMessager().printMessage(
                                Kind.ERROR,
                                "EventListener methods must be public static",
                                m);
                    }
                }

                registerMethods(results);
            } catch(final IOException ioe) {
                processingEnv.getMessager().printMessage(
                        Kind.ERROR,
                        "I/O Error during processing.");

                ioe.printStackTrace();
            }

            return true;
        }

        return false;
    }

}
