package eventbus;

import java.util.EventObject;

/**
 * This is the root class of events sent through the Event Bus object.
 * In addition to the normal "event source" object carried by an
 * {@code EventObject}, a {@code BusEventObject} includes a name
 * field. The names of the events may be filtered by the event
 * listeners in order to ignore events from certain sources, or
 * specific types of events.
 *
 * @author Jason Morris
 */
public abstract class BusEventObject extends EventObject {

    /**
     * This is the name of the {@code BusEventObject}, and is used
     * to filter out specific events during dispatch.
     *
     * @see EventListener#name()
     */
    private final String name;

    /**
     * Create a new {@code BusEventObject} with a specified source and
     * name.
     * 
     * @param source the source that triggered this event
     * @param name the name of this event
     * @throws IllegalArgumentException if the source is null, or the name
     *      is null or empty
     */
    public BusEventObject(
            final Object source,
            final String name) {

        super(source);

        if(name == null || name.isEmpty()) {
            throw new IllegalArgumentException("empty or null name");
        }

        this.name = name;
    }

    /**
     * Returns the name of this {@code BusEventObject}, as specified in
     * the constructor.
     *
     * @return the name of this {@code BusEventObject}
     * @see EventListener#name() 
     */
    public String getName() {
        return name;
    }

}
