package pjAriusTextoDuplicidade;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

/**
 * Classe Utilit�ria para Avaliar Duplicidade em linhas de Arquivos
 * @author Paulo Barreto
 * @date 30/05/2019
 */

public class LinhasRepetidas {
	static class Hash {
		private byte[] bytes = new byte[16];
		private static MessageDigest digest;
		static {
			try { 
				digest = MessageDigest.getInstance ("MD5"); 
			} catch (NoSuchAlgorithmException ex) { 
				ex.printStackTrace();
			}
		}

		//Gera��o do Hash para identifica��o da linha
		public Hash (byte[] linha) { 
			digest.reset();
			bytes = digest.digest (linha);
		}
		public boolean equals (Object obj) {
			if (obj instanceof Hash) {
				return Arrays.equals (bytes, ((Hash)obj).bytes);
			}
			return false;
		}
		//Retorna o HashCode do elemento
		public int hashCode () {
			int hash = 0;
			for (int i = 0; i < bytes.length; ++i) {
				hash = hash * 37 + (bytes[i] & 0xFF);
			}
			return hash;
		}		
	}
	
	public static String mimificacao(String fonte) {
		String saida = fonte.replaceAll("\t","").replaceAll("\n", " ");
		return saida;
	}
	
	public static String estruturas(String fonte) {
		String saida = fonte.replaceAll(";",";\n").replaceAll("end;/ ", "end;/\n");
		return saida;
	}

	public static void main (String[] args) throws Exception {
		Set<Hash> hashes = new HashSet<Hash>();		
		
		String linha;		
		
		//Mimifica��o
		BufferedReader arquivoOrigem = new BufferedReader (new FileReader ("./src/proreg.sql"));		
		BufferedWriter arquivoDestino = new BufferedWriter (new FileWriter ("./src/proreg_mimi.sql"));

		String fonte = "";
		int contagem = 0;		
		while ((linha = arquivoOrigem.readLine ()) != null) {
			fonte += linha;
			contagem++;
			if(contagem % 5000 == 0) {
				System.out.println(contagem);
			}
		}
		
		arquivoDestino.write (mimificacao(fonte));
		arquivoDestino.newLine();
		arquivoOrigem.close();
		arquivoDestino.close();
		
		//Estruturar Arquivo
		arquivoOrigem = new BufferedReader (new FileReader ("./src/proreg_mimi.sql"));
		arquivoDestino = new BufferedWriter (new FileWriter ("./src/proreg_e.txt"));

		fonte = "";
		while ((linha = arquivoOrigem.readLine ()) != null) {
			fonte += linha;
		}
		arquivoDestino.write (estruturas(fonte)); 
		arquivoDestino.newLine();
		
		arquivoOrigem.close();
		arquivoDestino.close();
		
	
		//Busca de ambiguidade
		arquivoOrigem = new BufferedReader (new FileReader ("./src/proreg_e.txt"));
		arquivoDestino = new BufferedWriter (new FileWriter ("./src/repetidos.txt"));
		
		int numLinhas = 0;
		while ((linha = arquivoOrigem.readLine ()) != null) {
			if(!linha.toUpperCase().equals("COMMIT;") 
					&& !linha.toUpperCase().equals("END;") 
					&& !linha.toUpperCase().equals("END LOOP;")
					&& !linha.toUpperCase().equals("END IF;") ) {
				Hash hashLinha = new Hash (linha.getBytes());
				if (hashes.contains (hashLinha)) {				
					System.out.println(linha);
					arquivoDestino.write (linha); 
					arquivoDestino.newLine();
					numLinhas++;
				}else {
					hashes.add (hashLinha);
				}
			}
		}		
		arquivoOrigem.close();
		arquivoDestino.close();
		System.out.println("Processo Conclu�do. Geradas " + numLinhas + " linhas");
	}
}